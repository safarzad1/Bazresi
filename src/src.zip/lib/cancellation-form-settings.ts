export const cancellationFontOptions = [
  { value: "IranNastaliq", label: "نستعلیق" },
  { value: "titr", label: "تیتر" },
  { value: "bnaznin", label: "بی‌نازنین" },
  { value: "PeydaFaNum_Regular", label: "پیدا" },
  { value: "IRANSansXMedium", label: "ایران‌سنس" },
  { value: "Shabnam", label: "شبنم" },
] as const;

export type CancellationFontName = (typeof cancellationFontOptions)[number]["value"];

export type CancellationFormSettings = {
  TitleFont: CancellationFontName;
  TitleFontSize: number;
  RecipientFont: CancellationFontName;
  RecipientFontSize: number;
  SignerFont: CancellationFontName;
  SignerFontSize: number;
  BodyFont: CancellationFontName;
  BodyFontSize: number;
  BodyLineHeight: number;
  ReasonsFont: CancellationFontName;
  ReasonsFontSize: number;
  ReasonsLineHeight: number;
  ReasonsRowHeight: number;
  CopyFont: CancellationFontName;
  CopyFontSize: number;
};

export const defaultCancellationFormSettings: CancellationFormSettings = {
  TitleFont: "IranNastaliq",
  TitleFontSize: 34,
  RecipientFont: "titr",
  RecipientFontSize: 21,
  SignerFont: "titr",
  SignerFontSize: 18,
  BodyFont: "bnaznin",
  BodyFontSize: 19,
  BodyLineHeight: 2.2,
  ReasonsFont: "bnaznin",
  ReasonsFontSize: 18,
  ReasonsLineHeight: 1.65,
  ReasonsRowHeight: 38,
  CopyFont: "bnaznin",
  CopyFontSize: 16,
};

const allowedFonts = new Set<CancellationFontName>(cancellationFontOptions.map((item) => item.value));

function font(value: unknown, fallback: CancellationFontName) {
  return typeof value === "string" && allowedFonts.has(value as CancellationFontName)
    ? value as CancellationFontName
    : fallback;
}

function number(value: unknown, fallback: number, min: number, max: number) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.round(parsed * 100) / 100));
}

export function normalizeCancellationFormSettings(value: unknown): CancellationFormSettings {
  const item = value && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
  const defaults = defaultCancellationFormSettings;

  return {
    TitleFont: font(item.TitleFont, defaults.TitleFont),
    TitleFontSize: number(item.TitleFontSize, defaults.TitleFontSize, 18, 60),
    RecipientFont: font(item.RecipientFont, defaults.RecipientFont),
    RecipientFontSize: number(item.RecipientFontSize, defaults.RecipientFontSize, 12, 40),
    SignerFont: font(item.SignerFont, defaults.SignerFont),
    SignerFontSize: number(item.SignerFontSize, defaults.SignerFontSize, 11, 36),
    BodyFont: font(item.BodyFont, defaults.BodyFont),
    BodyFontSize: number(item.BodyFontSize, defaults.BodyFontSize, 11, 30),
    BodyLineHeight: number(item.BodyLineHeight, defaults.BodyLineHeight, 1.2, 3),
    ReasonsFont: font(item.ReasonsFont, defaults.ReasonsFont),
    ReasonsFontSize: number(item.ReasonsFontSize, defaults.ReasonsFontSize, 10, 28),
    ReasonsLineHeight: number(item.ReasonsLineHeight, defaults.ReasonsLineHeight, 1.1, 3),
    ReasonsRowHeight: number(item.ReasonsRowHeight, defaults.ReasonsRowHeight, 24, 100),
    CopyFont: font(item.CopyFont, defaults.CopyFont),
    CopyFontSize: number(item.CopyFontSize, defaults.CopyFontSize, 10, 28),
  };
}

export function cancellationFontFamily(fontName: CancellationFontName) {
  return `${fontName}, Tahoma, Arial, sans-serif`;
}
