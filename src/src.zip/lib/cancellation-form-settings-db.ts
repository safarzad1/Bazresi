import {
  defaultCancellationFormSettings,
  normalizeCancellationFormSettings,
  type CancellationFormSettings,
} from "@/lib/cancellation-form-settings";
import { getDbPool } from "@/lib/db";

export async function getCancellationFormSettings() {
  const pool = await getDbPool();
  const result = await pool
    .request()
    .execute("bz.SP_Appointments_CancellationFormSettings_Get");
  return normalizeCancellationFormSettings(result.recordset?.[0] ?? defaultCancellationFormSettings);
}

export async function saveCancellationFormSettings(actorUserId: string, settings: CancellationFormSettings) {
  const pool = await getDbPool();
  const result = await pool
    .request()
    .input("ActorUserId", actorUserId)
    .input("TitleFont", settings.TitleFont)
    .input("TitleFontSize", settings.TitleFontSize)
    .input("RecipientFont", settings.RecipientFont)
    .input("RecipientFontSize", settings.RecipientFontSize)
    .input("SignerFont", settings.SignerFont)
    .input("SignerFontSize", settings.SignerFontSize)
    .input("BodyFont", settings.BodyFont)
    .input("BodyFontSize", settings.BodyFontSize)
    .input("BodyLineHeight", settings.BodyLineHeight)
    .input("ReasonsFont", settings.ReasonsFont)
    .input("ReasonsFontSize", settings.ReasonsFontSize)
    .input("ReasonsLineHeight", settings.ReasonsLineHeight)
    .input("ReasonsRowHeight", settings.ReasonsRowHeight)
    .input("CopyFont", settings.CopyFont)
    .input("CopyFontSize", settings.CopyFontSize)
    .execute("bz.SP_Appointments_CancellationFormSettings_Save");
  return normalizeCancellationFormSettings(result.recordset?.[0] ?? settings);
}
