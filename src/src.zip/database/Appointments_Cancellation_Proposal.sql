USE [DBBazresi];
GO

/*
    پیشنهاد لغو ابلاغ
    - تکمیل خودکار مشخصات از انتصاب جاری و اطلاعات شخص
    - ثبت دلایل به‌صورت ردیف‌های مستقل
    - نگهداری تصویر نهایی فرم به‌صورت SVG خودکفا
    - عدم تغییر وضعیت انتصاب تا زمان فرایند تأیید نهایی
*/

IF COL_LENGTH(N'bz.LaghveEblagh', N'EntesabId') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [EntesabId] BIGINT NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'RequestingPostId') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [RequestingPostId] BIGINT NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'RequesterFullName') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [RequesterFullName] NVARCHAR(150) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'RequesterPostTitle') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [RequesterPostTitle] NVARCHAR(250) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'SignaturePath') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [SignaturePath] NVARCHAR(500) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'DocumentSvg') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [DocumentSvg] NVARCHAR(MAX) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'DocumentHash') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [DocumentHash] NVARCHAR(64) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh', N'RegisteredAt') IS NULL
    ALTER TABLE [bz].[LaghveEblagh] ADD [RegisteredAt] DATETIME2(0) NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh_Ellat', N'LaghveEblaghId') IS NULL
    ALTER TABLE [bz].[LaghveEblagh_Ellat] ADD [LaghveEblaghId] BIGINT NULL;
GO

IF COL_LENGTH(N'bz.LaghveEblagh_Ellat', N'SortOrder') IS NULL
    ALTER TABLE [bz].[LaghveEblagh_Ellat] ADD [SortOrder] TINYINT NULL;
GO

IF OBJECT_ID(N'bz.CancellationFormSettings', N'U') IS NULL
BEGIN
    CREATE TABLE [bz].[CancellationFormSettings]
    (
        [ID] TINYINT NOT NULL,
        [TitleFont] NVARCHAR(50) NOT NULL,
        [TitleFontSize] DECIMAL(5,2) NOT NULL,
        [RecipientFont] NVARCHAR(50) NOT NULL,
        [RecipientFontSize] DECIMAL(5,2) NOT NULL,
        [SignerFont] NVARCHAR(50) NOT NULL,
        [SignerFontSize] DECIMAL(5,2) NOT NULL,
        [BodyFont] NVARCHAR(50) NOT NULL,
        [BodyFontSize] DECIMAL(5,2) NOT NULL,
        [BodyLineHeight] DECIMAL(5,2) NOT NULL,
        [ReasonsFont] NVARCHAR(50) NOT NULL,
        [ReasonsFontSize] DECIMAL(5,2) NOT NULL,
        [ReasonsLineHeight] DECIMAL(5,2) NOT NULL,
        [ReasonsRowHeight] DECIMAL(6,2) NOT NULL,
        [CopyFont] NVARCHAR(50) NOT NULL,
        [CopyFontSize] DECIMAL(5,2) NOT NULL,
        [UpdatedByUserId] NVARCHAR(450) NULL,
        [UpdatedAt] DATETIME2(0) NULL,
        CONSTRAINT [PK_CancellationFormSettings] PRIMARY KEY ([ID]),
        CONSTRAINT [CK_CancellationFormSettings_OneRow] CHECK ([ID] = 1)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM [bz].[CancellationFormSettings] WHERE [ID] = 1)
BEGIN
    INSERT INTO [bz].[CancellationFormSettings]
    (
        [ID], [TitleFont], [TitleFontSize], [RecipientFont], [RecipientFontSize],
        [SignerFont], [SignerFontSize], [BodyFont], [BodyFontSize], [BodyLineHeight],
        [ReasonsFont], [ReasonsFontSize], [ReasonsLineHeight], [ReasonsRowHeight],
        [CopyFont], [CopyFontSize], [UpdatedAt]
    )
    VALUES
    (
        1, N'IranNastaliq', 34, N'titr', 21,
        N'titr', 18, N'bnaznin', 19, 2.20,
        N'bnaznin', 18, 1.65, 38,
        N'bnaznin', 16, GETDATE()
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE [name] = N'FK_LaghveEblagh_Entesabat'
      AND [parent_object_id] = OBJECT_ID(N'bz.LaghveEblagh')
)
BEGIN
    ALTER TABLE [bz].[LaghveEblagh] WITH NOCHECK
        ADD CONSTRAINT [FK_LaghveEblagh_Entesabat]
        FOREIGN KEY ([EntesabId]) REFERENCES [bz].[Entesabat]([EntesabId]);
END;
GO

CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CancellationFormSettings_Get]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
        [TitleFont], [TitleFontSize], [RecipientFont], [RecipientFontSize],
        [SignerFont], [SignerFontSize], [BodyFont], [BodyFontSize], [BodyLineHeight],
        [ReasonsFont], [ReasonsFontSize], [ReasonsLineHeight], [ReasonsRowHeight],
        [CopyFont], [CopyFontSize]
    FROM [bz].[CancellationFormSettings]
    WHERE [ID] = 1;
END;
GO

CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CancellationFormSettings_Save]
    @ActorUserId NVARCHAR(450),
    @TitleFont NVARCHAR(50),
    @TitleFontSize DECIMAL(5,2),
    @RecipientFont NVARCHAR(50),
    @RecipientFontSize DECIMAL(5,2),
    @SignerFont NVARCHAR(50),
    @SignerFontSize DECIMAL(5,2),
    @BodyFont NVARCHAR(50),
    @BodyFontSize DECIMAL(5,2),
    @BodyLineHeight DECIMAL(5,2),
    @ReasonsFont NVARCHAR(50),
    @ReasonsFontSize DECIMAL(5,2),
    @ReasonsLineHeight DECIMAL(5,2),
    @ReasonsRowHeight DECIMAL(6,2),
    @CopyFont NVARCHAR(50),
    @CopyFontSize DECIMAL(5,2)
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS
    (
        SELECT 1
        FROM [dbo].[AspNetUserRoles] AS UR
        INNER JOIN [dbo].[AspNetRoles] AS R ON R.[Id] = UR.[RoleId]
        WHERE UR.[UserId] = @ActorUserId
          AND R.[Name] IN (N'Admin', N'a_root')
    )
        THROW 51120, N'فقط مدیر سامانه اجازه تغییر تنظیمات قالب را دارد.', 1;

    IF @TitleFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
       OR @RecipientFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
       OR @SignerFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
       OR @BodyFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
       OR @ReasonsFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
       OR @CopyFont NOT IN (N'IranNastaliq', N'titr', N'bnaznin', N'PeydaFaNum_Regular', N'IRANSansXMedium', N'Shabnam')
        THROW 51121, N'فونت انتخاب‌شده معتبر نیست.', 1;

    IF @TitleFontSize NOT BETWEEN 18 AND 60
       OR @RecipientFontSize NOT BETWEEN 12 AND 40
       OR @SignerFontSize NOT BETWEEN 11 AND 36
       OR @BodyFontSize NOT BETWEEN 11 AND 30
       OR @ReasonsFontSize NOT BETWEEN 10 AND 28
       OR @CopyFontSize NOT BETWEEN 10 AND 28
       OR @BodyLineHeight NOT BETWEEN 1.20 AND 3.00
       OR @ReasonsLineHeight NOT BETWEEN 1.10 AND 3.00
       OR @ReasonsRowHeight NOT BETWEEN 24 AND 100
        THROW 51122, N'اندازه فونت یا فاصله خطوط خارج از محدوده مجاز است.', 1;

    UPDATE [bz].[CancellationFormSettings]
    SET [TitleFont] = @TitleFont,
        [TitleFontSize] = @TitleFontSize,
        [RecipientFont] = @RecipientFont,
        [RecipientFontSize] = @RecipientFontSize,
        [SignerFont] = @SignerFont,
        [SignerFontSize] = @SignerFontSize,
        [BodyFont] = @BodyFont,
        [BodyFontSize] = @BodyFontSize,
        [BodyLineHeight] = @BodyLineHeight,
        [ReasonsFont] = @ReasonsFont,
        [ReasonsFontSize] = @ReasonsFontSize,
        [ReasonsLineHeight] = @ReasonsLineHeight,
        [ReasonsRowHeight] = @ReasonsRowHeight,
        [CopyFont] = @CopyFont,
        [CopyFontSize] = @CopyFontSize,
        [UpdatedByUserId] = @ActorUserId,
        [UpdatedAt] = GETDATE()
    WHERE [ID] = 1;

    EXEC [bz].[SP_Appointments_CancellationFormSettings_Get];
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE [name] = N'FK_LaghveEblaghEllat_LaghveEblagh'
      AND [parent_object_id] = OBJECT_ID(N'bz.LaghveEblagh_Ellat')
)
BEGIN
    ALTER TABLE [bz].[LaghveEblagh_Ellat] WITH NOCHECK
        ADD CONSTRAINT [FK_LaghveEblaghEllat_LaghveEblagh]
        FOREIGN KEY ([LaghveEblaghId]) REFERENCES [bz].[LaghveEblagh]([ID]);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE [name] = N'IX_LaghveEblagh_EntesabId_RecordState'
      AND [object_id] = OBJECT_ID(N'bz.LaghveEblagh')
)
BEGIN
    CREATE INDEX [IX_LaghveEblagh_EntesabId_RecordState]
        ON [bz].[LaghveEblagh]([EntesabId], [RecordState]);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE [name] = N'IX_LaghveEblaghEllat_Request'
      AND [object_id] = OBJECT_ID(N'bz.LaghveEblagh_Ellat')
)
BEGIN
    CREATE INDEX [IX_LaghveEblaghEllat_Request]
        ON [bz].[LaghveEblagh_Ellat]([LaghveEblaghId], [SortOrder]);
END;
GO

CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CancellationDraft_Get]
    @ActorUserId NVARCHAR(450),
    @EntesabId BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActorPostId BIGINT;
    DECLARE @RequesterFullName NVARCHAR(150);
    DECLARE @RequesterPostTitle NVARCHAR(250);
    DECLARE @SignaturePath NVARCHAR(500);

    SELECT TOP (1)
        @ActorPostId = TRY_CONVERT(BIGINT, U.[Semat]),
        @RequesterFullName = U.[FullName],
        @RequesterPostTitle = S.[OnvanSemat]
    FROM [dbo].[AspNetUsers] AS U
    LEFT JOIN [dbo].[Semats] AS S ON S.[ID] = TRY_CONVERT(BIGINT, U.[Semat])
    WHERE U.[Id] = @ActorUserId
      AND ISNULL(U.[IsDelete], 0) = 0
      AND ISNULL(U.[IsActive], 1) = 1;

    SELECT TOP (1) @SignaturePath = SG.[PathFile]
    FROM [bz].[Signature] AS SG
    WHERE SG.[UserId] = @ActorUserId
    ORDER BY SG.[Id] DESC;

    IF @ActorPostId IS NULL
        THROW 51100, N'سمت سازمانی فعال برای کاربر جاری پیدا نشد.', 1;

    SELECT ISNULL
    (
        (
            SELECT TOP (1)
                E.[EntesabId],
                E.[PersonId],
                E.[CodeMelli],
                E.[FirstName],
                E.[LastName],
                E.[FullName],
                E.[FatherName],
                E.[TarikhTavalod],
                ISNULL(P.[ShomareShenasnameh], N'') AS [ShomareShenasnameh],
                E.[PostId],
                COALESCE(NULLIF(LTRIM(RTRIM(S.[OnvanSemat])), N''), E.[PostOnvan]) AS [PostOnvan],
                E.[TarikhEblagh],
                E.[ModatEblagKhedmat],
                dbo.MiladiToShamsi
                (
                    DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh]))
                ) AS [TarikhPayan],
                DATEDIFF
                (
                    DAY,
                    CONVERT(DATE, GETDATE()),
                    DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh]))
                ) AS [DaysLeft],
                @ActorPostId AS [RequestingPostId],
                @RequesterFullName AS [RequesterFullName],
                @RequesterPostTitle AS [RequesterPostTitle],
                @SignaturePath AS [SignaturePath]
            FROM [bz].[Entesabat] AS E
            INNER JOIN [dbo].[Semats] AS S ON S.[ID] = E.[PostId]
            LEFT JOIN [bz].[Person] AS P ON P.[PersonId] = E.[PersonId]
            WHERE E.[EntesabId] = @EntesabId
              AND E.[RecordState] = 10
              AND E.[TaeedOrAdamTaeed] = 4
              AND ISNULL(E.[KartablOthePost], 0) = 0
              AND ISNULL(E.[IsDelete], 0) = 0
              AND ISNULL(E.[IsEblagh], 0) = 1
              AND DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh])) >= CONVERT(DATE, GETDATE())
              AND EXISTS
              (
                  SELECT 1
                  FROM [bz].[AppointmentPostAccess] AS A
                  WHERE A.[ActorPostId] = @ActorPostId
                    AND A.[TargetPostId] = E.[PostId]
                    AND A.[IsActive] = 1
              )
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM [bz].[LaghveEblagh] AS L
                  WHERE L.[EntesabId] = E.[EntesabId]
                    AND L.[RecordState] = 10
              )
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
        ),
        N'{}'
    ) AS [JsonResult];
END;
GO

CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CancellationProposal_Create]
    @ActorUserId NVARCHAR(450),
    @EntesabId BIGINT,
    @ReasonsJson NVARCHAR(MAX),
    @DocumentSvg NVARCHAR(MAX),
    @DocumentHash NVARCHAR(64)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF ISJSON(@ReasonsJson) <> 1
        THROW 51101, N'ساختار دلایل لغو ابلاغ معتبر نیست.', 1;

    IF NULLIF(LTRIM(RTRIM(ISNULL(@DocumentSvg, N''))), N'') IS NULL
        THROW 51102, N'تصویر فرم لغو ابلاغ تولید نشده است.', 1;

    DECLARE @ReasonCount INT =
    (
        SELECT COUNT(1)
        FROM OPENJSON(@ReasonsJson)
        WHERE NULLIF(LTRIM(RTRIM(CONVERT(NVARCHAR(1500), [value]))), N'') IS NOT NULL
    );

    IF @ReasonCount < 1 OR @ReasonCount > 10
        THROW 51103, N'حداقل یک و حداکثر ده دلیل وارد کنید.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM OPENJSON(@ReasonsJson)
        WHERE LEN(LTRIM(RTRIM(CONVERT(NVARCHAR(MAX), [value])))) > 220
    )
        THROW 51104, N'هر دلیل باید حداکثر ۲۲۰ نویسه باشد.', 1;

    DECLARE @ActorPostId BIGINT;
    DECLARE @RequesterFullName NVARCHAR(150);
    DECLARE @RequesterPostTitle NVARCHAR(250);
    DECLARE @SignaturePath NVARCHAR(500);

    SELECT TOP (1)
        @ActorPostId = TRY_CONVERT(BIGINT, U.[Semat]),
        @RequesterFullName = U.[FullName],
        @RequesterPostTitle = S.[OnvanSemat]
    FROM [dbo].[AspNetUsers] AS U
    LEFT JOIN [dbo].[Semats] AS S ON S.[ID] = TRY_CONVERT(BIGINT, U.[Semat])
    WHERE U.[Id] = @ActorUserId
      AND ISNULL(U.[IsDelete], 0) = 0
      AND ISNULL(U.[IsActive], 1) = 1;

    SELECT TOP (1) @SignaturePath = SG.[PathFile]
    FROM [bz].[Signature] AS SG
    WHERE SG.[UserId] = @ActorUserId
    ORDER BY SG.[Id] DESC;

    IF @ActorPostId IS NULL
        THROW 51105, N'سمت سازمانی فعال برای کاربر جاری پیدا نشد.', 1;

    DECLARE
        @PersonId BIGINT,
        @CodeMelli NVARCHAR(10),
        @FirstName NVARCHAR(150),
        @LastName NVARCHAR(150),
        @FatherName NVARCHAR(150),
        @TarikhTavalod NVARCHAR(10),
        @ShomareShenasnameh NVARCHAR(20),
        @PostId BIGINT,
        @PostOnvan NVARCHAR(500),
        @TarikhEblagh NVARCHAR(20),
        @ModatEblagKhedmat INT,
        @TarikhPayan NVARCHAR(10),
        @NoeMasuliyat INT;

    SELECT TOP (1)
        @PersonId = E.[PersonId],
        @CodeMelli = E.[CodeMelli],
        @FirstName = E.[FirstName],
        @LastName = E.[LastName],
        @FatherName = E.[FatherName],
        @TarikhTavalod = E.[TarikhTavalod],
        @ShomareShenasnameh = ISNULL(P.[ShomareShenasnameh], N''),
        @PostId = E.[PostId],
        @PostOnvan = COALESCE(NULLIF(LTRIM(RTRIM(S.[OnvanSemat])), N''), E.[PostOnvan]),
        @TarikhEblagh = E.[TarikhEblagh],
        @ModatEblagKhedmat = E.[ModatEblagKhedmat],
        @TarikhPayan = dbo.MiladiToShamsi
        (
            DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh]))
        ),
        @NoeMasuliyat = ISNULL(S.[TypeSemat], 0)
    FROM [bz].[Entesabat] AS E
    INNER JOIN [dbo].[Semats] AS S ON S.[ID] = E.[PostId]
    LEFT JOIN [bz].[Person] AS P ON P.[PersonId] = E.[PersonId]
    WHERE E.[EntesabId] = @EntesabId
      AND E.[RecordState] = 10
      AND E.[TaeedOrAdamTaeed] = 4
      AND ISNULL(E.[KartablOthePost], 0) = 0
      AND ISNULL(E.[IsDelete], 0) = 0
      AND ISNULL(E.[IsEblagh], 0) = 1
      AND DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh])) >= CONVERT(DATE, GETDATE())
      AND EXISTS
      (
          SELECT 1
          FROM [bz].[AppointmentPostAccess] AS A
          WHERE A.[ActorPostId] = @ActorPostId
            AND A.[TargetPostId] = E.[PostId]
            AND A.[IsActive] = 1
      );

    IF @PersonId IS NULL
        THROW 51106, N'ابلاغ جاری یا مجوز لغو آن پیدا نشد.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF EXISTS
        (
            SELECT 1
            FROM [bz].[LaghveEblagh] WITH (UPDLOCK, HOLDLOCK)
            WHERE [EntesabId] = @EntesabId
              AND [RecordState] = 10
        )
            THROW 51107, N'برای این ابلاغ قبلاً پیشنهاد لغو ثبت شده است.', 1;

        INSERT INTO [bz].[LaghveEblagh]
        (
            [PersonId], [CodeMelli], [FirstName], [LastName], [FatherName],
            [TarikhTavalod], [ShomareShenasnameh], [Shoghl], [TarikhShoro],
            [Moddat], [NoeMasuliyat], [NoeMasuliyat_NameFarsi], [TarikhPayan],
            [Ellat], [Ellat_NameFarsi], [RecordState], [RecordState_NameFarsi],
            [CreateUserId], [CreateDateTime], [EntesabId], [RequestingPostId],
            [RequesterFullName], [RequesterPostTitle], [SignaturePath],
            [DocumentSvg], [DocumentHash], [RegisteredAt]
        )
        VALUES
        (
            @PersonId, @CodeMelli, @FirstName, @LastName, @FatherName,
            @TarikhTavalod, @ShomareShenasnameh, @PostOnvan, @TarikhEblagh,
            @ModatEblagKhedmat, @NoeMasuliyat, @PostOnvan, @TarikhPayan,
            1, N'لغو ابلاغ', 10, N'پیشنهاد لغو ابلاغ',
            @ActorUserId, CONVERT(NVARCHAR(19), GETDATE(), 120), @EntesabId, @ActorPostId,
            @RequesterFullName, @RequesterPostTitle, @SignaturePath,
            @DocumentSvg, @DocumentHash, GETDATE()
        );

        DECLARE @LaghveEblaghId BIGINT = SCOPE_IDENTITY();

        INSERT INTO [bz].[LaghveEblagh_Ellat]
        (
            [PersonId], [Dalayel], [CreateUserId], [CreateDateTime],
            [LaghveEblaghId], [SortOrder]
        )
        SELECT
            @PersonId,
            LTRIM(RTRIM(CONVERT(NVARCHAR(1500), [value]))),
            @ActorUserId,
            CONVERT(NVARCHAR(19), GETDATE(), 120),
            @LaghveEblaghId,
            CONVERT(TINYINT, CONVERT(INT, [key]) + 1)
        FROM OPENJSON(@ReasonsJson)
        WHERE NULLIF(LTRIM(RTRIM(CONVERT(NVARCHAR(1500), [value]))), N'') IS NOT NULL
          AND TRY_CONVERT(INT, [key]) BETWEEN 0 AND 9;

        COMMIT TRANSACTION;

        SELECT
            @LaghveEblaghId AS [ProposalId],
            @DocumentHash AS [DocumentHash];
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CancellationDocument_Get]
    @ActorUserId NVARCHAR(450),
    @ProposalId BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActorPostId BIGINT;
    SELECT TOP (1) @ActorPostId = TRY_CONVERT(BIGINT, U.[Semat])
    FROM [dbo].[AspNetUsers] AS U
    WHERE U.[Id] = @ActorUserId
      AND ISNULL(U.[IsDelete], 0) = 0
      AND ISNULL(U.[IsActive], 1) = 1;

    SELECT TOP (1)
        L.[ID] AS [ProposalId],
        L.[DocumentSvg],
        L.[DocumentHash],
        L.[FirstName],
        L.[LastName]
    FROM [bz].[LaghveEblagh] AS L
    INNER JOIN [bz].[Entesabat] AS E ON E.[EntesabId] = L.[EntesabId]
    WHERE L.[ID] = @ProposalId
      AND L.[DocumentSvg] IS NOT NULL
      AND
      (
          L.[CreateUserId] = @ActorUserId
          OR L.[RequestingPostId] = @ActorPostId
          OR EXISTS
          (
              SELECT 1
              FROM [bz].[AppointmentPostAccess] AS A
              WHERE A.[ActorPostId] = @ActorPostId
                AND A.[TargetPostId] = E.[PostId]
                AND A.[IsActive] = 1
          )
      );
END;
GO

/* به‌روزرسانی فهرست جاری برای مخفی‌شدن عملیات پس از ثبت پیشنهاد لغو */
CREATE OR ALTER PROCEDURE [bz].[SP_Appointments_CurrentByAccess]
    @ActorUserId NVARCHAR(450)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ActorPostId BIGINT;

    SELECT TOP (1) @ActorPostId = TRY_CONVERT(BIGINT, U.[Semat])
    FROM [dbo].[AspNetUsers] AS U
    WHERE U.[Id] = @ActorUserId
      AND ISNULL(U.[IsDelete], 0) = 0
      AND ISNULL(U.[IsActive], 1) = 1;

    IF @ActorPostId IS NULL
        THROW 51005, N'سمت سازمانی فعال برای کاربر جاری پیدا نشد.', 1;

    SELECT ISNULL
    (
        (
            SELECT
                E.[EntesabId], E.[PersonId], E.[CodeMelli], E.[FirstName], E.[LastName], E.[FullName], E.[PostId],
                COALESCE(NULLIF(LTRIM(RTRIM(S.[OnvanSemat])), N''), E.[PostOnvan]) AS [PostOnvan],
                S.[PID] AS [ParentPostId], NULL AS [TreeLevel], S.[Mahal],
                E.[TarikhEblagh], E.[ModatEblagKhedmat],
                dbo.MiladiToShamsi
                (
                    DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh]))
                ) AS [TarikhLaghv],
                DATEDIFF
                (
                    DAY, CONVERT(DATE, GETDATE()),
                    DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh]))
                ) AS [DaysLeft],
                E.[RecordState], E.[RecordState_NameFarsi], E.[TaeedOrAdamTaeed],
                E.[TaeedOrAdamTaeedNameFarsi], E.[IsEblagh],
                CONVERT
                (
                    BIT,
                    CASE
                        WHEN E.[RecordState] = 10
                         AND E.[TaeedOrAdamTaeed] = 4
                         AND DATEADD(MONTH, E.[ModatEblagKhedmat], dbo.ShamsiToMiladi(E.[TarikhEblagh])) >= CONVERT(DATE, GETDATE())
                         AND NOT EXISTS
                         (
                             SELECT 1
                             FROM [bz].[LaghveEblagh] AS L
                             WHERE L.[EntesabId] = E.[EntesabId]
                               AND L.[RecordState] = 10
                         )
                            THEN 1
                        ELSE 0
                    END
                ) AS [CanCancel],
                ISNULL
                (
                    (
                        SELECT
                            EM.[Id], EM.[OnvanSanad], EM.[CreateDateTime],
                            CASE
                                WHEN CHARINDEX(N'\', REVERSE(ISNULL(EM.[FileName], N''))) > 0
                                    THEN RIGHT(EM.[FileName], CHARINDEX(N'\', REVERSE(EM.[FileName])) - 1)
                                ELSE EM.[FileName]
                            END AS [FullFileName]
                        FROM [bz].[Entesabat_Madarek] AS EM
                        WHERE EM.[PersonId] = E.[PersonId]
                        ORDER BY EM.[CreateDateTime] DESC
                        FOR JSON PATH, INCLUDE_NULL_VALUES
                    ),
                    N'[]'
                ) AS [Madarek]
            FROM [bz].[Entesabat] AS E
            INNER JOIN [dbo].[Semats] AS S ON S.[ID] = E.[PostId]
            WHERE E.[RecordState] = 10
              AND E.[TaeedOrAdamTaeed] = 4
              AND ISNULL(E.[KartablOthePost], 0) = 0
              AND ISNULL(E.[IsDelete], 0) = 0
              AND ISNULL(E.[IsEblagh], 0) = 1
              AND EXISTS
              (
                  SELECT 1
                  FROM [bz].[AppointmentPostAccess] AS A
                  WHERE A.[ActorPostId] = @ActorPostId
                    AND A.[TargetPostId] = E.[PostId]
                    AND A.[IsActive] = 1
              )
            ORDER BY E.[PostId], E.[EntesabId]
            FOR JSON PATH, INCLUDE_NULL_VALUES
        ),
        N'[]'
    ) AS [JsonResult];
END;
GO
